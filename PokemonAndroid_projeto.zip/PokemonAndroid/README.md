# Pokémon Pixel — projeto Android (base APK)

Este projeto abre o protótipo HTML incorporado em um WebView, em tela cheia e horizontal, sem depender de navegador ou internet.

## Gerar o APK no Android Studio
1. Instale o Android Studio em um computador e abra esta pasta (`PokemonAndroid`).
2. Aguarde o Gradle sincronizar e instalar o Android SDK Platform 35, se solicitado.
3. Menu **Build > Build APK(s)**.
4. O APK de teste ficará em `app/build/outputs/apk/debug/app-debug.apk`.
5. Transfira o APK para o Android, abra-o e autorize a instalação de aplicativos dessa fonte, se solicitado.

## Atualizações do jogo
As futuras versões do HTML devem substituir `app/src/main/assets/index.html`. Para atualizações instaláveis, mantenha o `applicationId` e assine os APKs de atualização com a mesma chave. O projeto inicial usa APK debug; não é um APK compilado nesta entrega.
